﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_Do_Curso_2.AluguelDeCarro.Entidade
{
    public abstract class EntidadeBase
    {
        public Guid ID { get; set; } 
    }
}
